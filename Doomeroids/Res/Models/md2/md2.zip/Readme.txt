Doom models and skins (adjusted to the Doom Pallette) lumped into one single zip 
file.

Most models originated with either the defunct Generations mod
(http://www.planetquake.com/generations/) or the Son of Generations mod
(http://sog.telefragged.com/).

Credits:

Monsters, Items, Decor, Skies: Edmundo Bordeu (ebordeu@rdc.cl)
Spherical Powerups, SS Guard: AklashPahk (lfcf@ig.com.br)
Weapon Models, HUD Weapon Models, Doom Marine Player Model: Derived from the 
Generations Project.