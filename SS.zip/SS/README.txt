Arrow Keys	- Rotate Camera

PgUp/PgDn	- Change Camera Distance (5%)
Home/End	- Change Camera Distance (x2)

Spacebar	- Change render mode (Points/Wireframe/Solid)

Number keys	- Set camera target (w = moon)
Keypad		- Set camera position (. = moon)

M		- Align planets
B		- Color gravity wells
Z		- Toggle grid
X		- Render "chain"

H		- Turn ambient light up
G		- Turn ambient light normal

/		- Set camera above solar system